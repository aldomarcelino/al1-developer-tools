export const VIEWERS = [
    "http://localhost:3000",
    "https://ramupod.com",
    "https://dotools.com",
];
export const VIEWER_PATH = "/tools/qa-bug-report";
export function viewerOrigin(value) {
    if (typeof value !== "string" || !VIEWERS.some((origin) => origin === value))
        throw new Error("Choose an explicitly allowed Ramupod origin.");
    return value;
}
export function validRecipient(sender, extensionId, handoff, nonce) {
    if (sender.id !== extensionId ||
        sender.frameId !== 0 ||
        sender.tab?.id !== handoff.tabId ||
        nonce !== handoff.nonce ||
        Date.now() > handoff.expires)
        return false;
    try {
        const url = new URL(sender.tab?.url ?? "");
        return url.origin === viewerOrigin(handoff.origin) && url.pathname === VIEWER_PATH;
    }
    catch {
        return false;
    }
}
