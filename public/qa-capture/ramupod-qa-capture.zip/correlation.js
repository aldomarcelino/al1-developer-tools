export function parseTraceparent(value) {
    const match = /^00-([0-9a-f]{32})-([0-9a-f]{16})-([0-9a-f]{2})$/.exec(value);
    if (!match || /^0+$/.test(match[1]) || /^0+$/.test(match[2]))
        return null;
    return { traceId: match[1], spanId: match[2], flags: match[3] };
}
export function identifiers(request) {
    const result = [];
    function add(name, value, source) {
        if (!value || value === "[REDACTED]")
            return;
        const key = name.toLowerCase().replace(/[^a-z]/g, "");
        if (key === "traceparent") {
            const parsed = parseTraceparent(value);
            result.push({
                name,
                value,
                kind: "traceparent",
                source,
                note: parsed
                    ? "Valid W3C version 00"
                    : "Not parsed: invalid or unsupported traceparent format/version",
            });
            if (parsed)
                result.push({
                    name: "trace-id",
                    value: parsed.traceId,
                    kind: "trace ID",
                    source: `${source} → trace-id`,
                }, {
                    name: "parent-id",
                    value: parsed.spanId,
                    kind: "span ID",
                    source: `${source} → parent-id (upstream span, not necessarily the server span)`,
                });
        }
        else {
            const kind = key === "requestid" || key === "xrequestid"
                ? source.startsWith("Response")
                    ? "server request ID"
                    : "request ID candidate"
                : key === "correlationid" || key === "xcorrelationid"
                    ? "correlation ID"
                    : key === "traceid" || key === "xtraceid"
                        ? "trace ID"
                        : key === "spanid" || key === "xspanid"
                            ? "span ID"
                            : null;
            if (kind)
                result.push({
                    name,
                    value,
                    kind,
                    source,
                    note: source.startsWith("Request")
                        ? "Observed in outgoing data; server adoption is not verified."
                        : "Captured identifier field; not verified against a tracing backend.",
                });
        }
    }
    for (const [label, headers] of [
        ["Request headers", request.headers],
        ["Response headers", request.response.headers],
    ])
        headers.forEach((h, i) => add(h.name, h.value, `${label}[${i}].${h.name}`));
    function visit(value, path, depth = 0) {
        if (depth > 15 || result.length >= 200)
            return;
        if (Array.isArray(value)) {
            value.slice(0, 100).forEach((v, i) => visit(v, `${path}[${i}]`, depth + 1));
            return;
        }
        if (!value || typeof value !== "object")
            return;
        for (const [name, v] of Object.entries(value)) {
            const location = `${path}[${JSON.stringify(name)}]`;
            if (typeof v === "string" || typeof v === "number")
                add(name, String(v), location);
            else
                visit(v, location, depth + 1);
            if (result.length >= 200)
                return;
        }
    }
    for (const [label, b] of [
        ["Request JSON body", request.body],
        ["Response JSON body", request.response.body],
    ]) {
        if (b.encoding !== "utf8")
            continue;
        try {
            visit(JSON.parse(b.text), label);
        }
        catch { }
    }
    return result;
}
export const defaultCandidateRules = {
    slowMs: 1000,
    businessEnabled: false,
    businessPath: "success",
    businessValue: "false",
};
export function candidateReasons(request, rules) {
    const result = [];
    if (request.response.status === 0)
        result.push("Network failure reported (status 0)");
    else if (request.response.status >= 400)
        result.push(`HTTP ${request.response.status}; may be expected application behavior`);
    if (Number.isFinite(rules.slowMs) &&
        rules.slowMs >= 1 &&
        request.durationMs !== null &&
        request.durationMs >= rules.slowMs)
        result.push(`Duration ≥ ${rules.slowMs} ms`);
    if (rules.businessEnabled &&
        request.response.status === 200 &&
        /^[a-zA-Z0-9_]+(?:\.[a-zA-Z0-9_]+){0,9}$/.test(rules.businessPath)) {
        try {
            let value = JSON.parse(request.response.body.text);
            for (const part of rules.businessPath.split("."))
                value =
                    value !== null && typeof value === "object" && Object.hasOwn(value, part)
                        ? value[part]
                        : undefined;
            const expected = JSON.parse(rules.businessValue);
            if (["string", "number", "boolean"].includes(typeof expected) || expected === null)
                if (value === expected)
                    result.push(`Business rule: response JSON ${rules.businessPath} = ${rules.businessValue}`);
        }
        catch { }
    }
    return result;
}
export function aroundMarker(requests, marker, beforeSeconds, afterSeconds) {
    if (!marker)
        return requests;
    return requests.filter((r) => r.sessionId === marker.sessionId &&
        Date.parse(r.startedAt) >= Date.parse(marker.at) - beforeSeconds * 1000 &&
        Date.parse(r.startedAt) <= Date.parse(marker.at) + afterSeconds * 1000);
}
