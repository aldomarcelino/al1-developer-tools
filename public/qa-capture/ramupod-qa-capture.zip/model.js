export const FORMAT = "ramupod-qa-evidence";
export const VERSION = 1;
export const limits = {
    requests: 250,
    markers: 100,
    bodyBytes: 65536,
    sessionBytes: 4 * 1024 * 1024,
    importBytes: 12 * 1024 * 1024,
    screenshotBytes: 2 * 1024 * 1024,
    screenshots: 2,
    durationMs: 15 * 60 * 1000,
};
export const bytes = (text) => new TextEncoder().encode(text).length;
export function newSession(pageUrl, capture, at = new Date().toISOString(), id = crypto.randomUUID()) {
    return {
        id,
        startedAt: at,
        endedAt: null,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        pageUrl,
        environment: { value: "", source: "not-provided" },
        build: { value: "", source: "not-provided" },
        browser: "",
        platform: "",
        tabId: null,
        capture,
        state: "idle",
        notices: [],
        requests: [],
        markers: [],
        attachments: [],
        redactions: [],
        report: {
            sessionId: id,
            title: "",
            description: "",
            preconditions: "",
            steps: "",
            expected: "",
            actual: "",
            frequency: "unknown",
            severity: "",
            requestIds: [],
            markerIds: [],
        },
    };
}
export function body(text, mimeType = "", status, reason = null, encoding = "utf8") {
    const size = text === undefined ? null : bytes(text);
    if (size !== null && size > limits.bodyBytes)
        return {
            text: "",
            mimeType,
            status: "Truncated",
            originalBytes: size,
            reason: "Body exceeds 64 KiB; content omitted.",
            encoding,
        };
    return {
        text: text ?? "",
        mimeType,
        encoding,
        originalBytes: size,
        status: status ?? (text === undefined ? "Unavailable" : text === "" ? "Empty" : "Captured"),
        reason,
    };
}
export function packageSession(session, redacted = false, markdown = "") {
    return {
        format: FORMAT,
        version: VERSION,
        manifest: {
            producer: "Ramupod QA",
            exportedAt: new Date().toISOString(),
            requestCount: session.requests.length,
            markerCount: session.markers.length,
            attachmentCount: session.attachments.length,
            redacted,
            reportMarkdown: markdown,
        },
        session,
    };
}
